package com.wipro.servelt;

import java.io.*;  
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;  
import javax.servlet.http.*;

import com.wipro.dao.RegisterDao;
import com.wipro.dao.logindao;  
  
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doCommon(request,response);
		System.out.println("get");
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doCommon(request, response);
		System.out.println("post");

	}
	protected void doCommon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String n=request.getParameter("name");  
		String p=request.getParameter("empid");  
		String e=request.getParameter("email");  
		String c=request.getParameter("psw");  
		
		System.out.println(" Register login servelet ");

		RegisterDao dao=new RegisterDao();
	    int r=dao.entryUser(n, p,e,c);
	    System.out.println(r);
	    if(r==1)
		{
			System.out.println("Registeration over");

			RequestDispatcher rd=request.getRequestDispatcher("/Success.jsp");
			rd.forward(request, response);
		}
		else
		{  
			System.out.println("servlet validation over but failed");

			RequestDispatcher rd=request.getRequestDispatcher("/Failure.jsp");
			rd.forward(request, response);
		}
		
	}

}  