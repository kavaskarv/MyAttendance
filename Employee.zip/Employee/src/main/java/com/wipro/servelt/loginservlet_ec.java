package com.wipro.servelt;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.dao.logindao;

/**
 * Servlet implementation class loginservlet_ec
 */
public class loginservlet_ec extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginservlet_ec() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doCommon(request,response);
		System.out.println("get");
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doCommon(request, response);
		System.out.println("post");

	}
	protected void doCommon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String x=request.getParameter("uname");
		String y=request.getParameter("psw");
		
		System.out.println(" login servelet ");

	    logindao dao=new logindao();
	    boolean r=dao.CheckUser(x, y);
	    System.out.println(r);
	    if(r)
		{
	    	
	    	if(x.equalsIgnoreCase("admin")) {
	    		RequestDispatcher rd=request.getRequestDispatcher("/Admin.jsp");
				rd.forward(request, response);
	    	}
	    	else {
	    		System.out.println("servlet validation over");
				RequestDispatcher rd=request.getRequestDispatcher("/dash.jsp");
				rd.forward(request, response);
	    	}
			
		}
		else
		{  
			System.out.println("servlet validation over but failed");
			RequestDispatcher rd=request.getRequestDispatcher("/LOGIN_CE.jsp");
			rd.forward(request, response);
		}
		
	}

}
