package com.wipro.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class AttendanceDao {
	


	public static void main(String[] args)
	{
		AttendanceDao dao=new AttendanceDao();
		dao.getConnection();
	}
	Connection conn=null;
	public Connection getConnection()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		try
		{
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/sonar","root", "devops");
			System.out.println("connected successfully");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		if(conn!=null)
			System.out.println("connected");
		else
			System.out.println("fail");
		return conn;
	}

	
	public int attendanceEntry(String a,String b,String c,String d)
	{
		if(conn==null)
		getConnection();
		try
		{
			System.out.println("entry");
		
				java.sql.PreparedStatement ps= 
					conn.prepareStatement
				("insert into attendance values(?,?,?,?)");
				ps.setString(1,a);  
				ps.setString(2,b);  
				ps.setString(3,c);  
				ps.setString(4,d);
					int k;
					k=ps.executeUpdate();
					return k; 
					}
		catch(Exception ex)
		{
			ex.printStackTrace();
			System.out.println("entry exception");
				}
		return 0;

	}

	




}
