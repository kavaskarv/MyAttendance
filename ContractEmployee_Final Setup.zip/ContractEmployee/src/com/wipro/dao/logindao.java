package com.wipro.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.lang.*;

import com.mysql.jdbc.PreparedStatement;



public class logindao {
	public static void main(String[] args)
	{
		logindao dao=new logindao();
		dao.getConnection();
	}
	Connection conn=null;
	public Connection getConnection()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		try
		{
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/sonar","root", "devops");
			System.out.println("connected successfully");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		if(conn!=null)
			System.out.println("connected");
		else
			System.out.println("fail");
		return conn;
	}
	public boolean CheckUser(String user1name,String pass)
	{
		if(conn==null)
		getConnection();
		try
		{
			java.sql.PreparedStatement ps=conn.prepareStatement("select * from REGISTERUSER where name=? and password=?");
			ps.setString(1,user1name);
			ps.setString(2,pass);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
				return true;
			else
				return false;
		}
				catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
		

	}
	public int entryUser(String euser,String epass)
	{
		if(conn==null)
		getConnection();
		try
		{
			System.out.println("entry");
		
				java.sql.PreparedStatement ps= 
					conn.prepareStatement
				("insert into userr values (?,?)");
					ps.setString(1,euser);
					ps.setString(2,epass);
					int k;
					k=ps.executeUpdate();
					return k; 
					}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("entry exception");
				}
		return 0;

	}

	
}
