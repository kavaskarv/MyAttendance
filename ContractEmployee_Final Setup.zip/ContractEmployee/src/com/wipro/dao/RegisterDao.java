package com.wipro.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RegisterDao {

	public static void main(String[] args)
	{
		RegisterDao dao=new RegisterDao();
		dao.getConnection();
	}
	Connection conn=null;
	public Connection getConnection()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		try
		{
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/sonar","root", "devops");
			System.out.println("connected successfully");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		if(conn!=null)
			System.out.println("connected");
		else
			System.out.println("fail");
		return conn;
	}

	/*
	 * public boolean CheckUser(String user1name,String pass) { if(conn==null)
	 * getConnection(); try { java.sql.PreparedStatement
	 * ps=conn.prepareStatement("select * from user where username=? and password=?"
	 * ); ps.setString(1,user1name); ps.setString(2,pass); ResultSet
	 * rs=ps.executeQuery(); if(rs.next()) return true; else return false; }
	 * catch(Exception e) { e.printStackTrace(); } return false;
	 * 
	 * 
	 * }
	 */
	public int entryUser(String n,String p,String e,String c)
	{
		if(conn==null)
		getConnection();
		try
		{
			System.out.println("entry");
		
				java.sql.PreparedStatement ps= 
					conn.prepareStatement
				("insert into registeruser values(?,?,?,?)");
				ps.setString(1,n);  
				ps.setString(2,p);  
				ps.setString(3,e);  
				ps.setString(4,c);
					int k;
					k=ps.executeUpdate();
					return k; 
					}
		catch(Exception ex)
		{
			ex.printStackTrace();
			System.out.println("entry exception");
				}
		return 0;

	}

	


}
