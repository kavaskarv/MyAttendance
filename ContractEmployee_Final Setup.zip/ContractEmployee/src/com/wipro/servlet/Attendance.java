package com.wipro.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.dao.AttendanceDao;
import com.wipro.dao.RegisterDao;

public class Attendance extends HttpServlet {
	

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Attendance() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doCommon(request,response);
		System.out.println("get");
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doCommon(request, response);
		System.out.println("post");

	}
	protected void doCommon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String a=request.getParameter("name");  
		String b=request.getParameter("empid");  
		String c=request.getParameter("in");  
		String d=request.getParameter("out");  
		
		System.out.println(" Register login servelet ");

		AttendanceDao dao=new AttendanceDao();
	    int r=dao.attendanceEntry(a, b,c,d);
	    System.out.println(r);
	    if(r==1)
		{
			System.out.println("Registeration over");

			RequestDispatcher rd=request.getRequestDispatcher("/Success.jsp");
			rd.forward(request, response);
		}
		else
		{  
			System.out.println("servlet validation over but failed");

			RequestDispatcher rd=request.getRequestDispatcher("/Failure.jsp");
			rd.forward(request, response);
		}
		
	}



}
